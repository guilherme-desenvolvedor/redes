<?php
/**
 * Teste de integração do banco (CLI). Usa o MySQL real configurado em app/config/database.php.
 * Cria dois usuários temporários, exercita todos os módulos e ao final remove tudo que criou.
 *
 * XAMPP (Windows):  C:\xampp\php\php.exe C:\xampp\htdocs\redes\tests\smoke_test.php
 */
if (PHP_SAPI !== 'cli') { http_response_code(403); exit('Execute apenas pelo terminal.'); }

define('ROOT', dirname(__DIR__));
define('APP_PATH', ROOT . '/app');
define('VIEW_PATH', APP_PATH . '/views');
require APP_PATH . '/core/helpers.php';
spl_autoload_register(function (string $c): void {
    foreach (['core', 'models', 'controllers'] as $d) { $f = APP_PATH . "/$d/$c.php"; if (is_file($f)) { require $f; return; } }
});
date_default_timezone_set(config('timezone'));

$ok = 0; $fail = 0;
function check(string $name, bool $cond): void {
    global $ok, $fail;
    echo ($cond ? "  [OK]   " : "  [FALHA] ") . $name . PHP_EOL;
    $cond ? $ok++ : $fail++;
}

$tag = 'smoke' . time() . bin2hex(random_bytes(2));
$emailA = "a.$tag@redes.test"; $emailB = "b.$tag@redes.test";
$idA = $idB = 0;

try {
    echo "Conexão com o MySQL\n";
    check('conecta ao banco configurado', Database::get() instanceof PDO);

    echo "\nCadastro e login\n";
    $idA = User::create('Usuário A', $emailA, 'senha-segura-A');
    $idB = User::create('Usuário B', $emailB, 'senha-segura-B');
    check('usuários criados', $idA > 0 && $idB > 0 && $idA !== $idB);
    $u = User::findByEmail($emailA);
    check('login: senha correta é aceita', $u && password_verify('senha-segura-A', $u['password']));
    check('login: senha errada é recusada', $u && !password_verify('errada', $u['password']));
    check('senha não é guardada em texto puro', $u && $u['password'] !== 'senha-segura-A');
    try { User::create('Duplicado', $emailA, 'x12345678'); check('e-mail duplicado é bloqueado', false); }
    catch (DatabaseException $e) { check('e-mail duplicado é bloqueado', $e->isDuplicate()); }

    echo "\nIdeias\n";
    $ideaId = Idea::create($idA, ['title' => 'Ideia 1', 'description' => 'desc', 'category' => 'Educativo', 'platform' => 'Instagram']);
    check('ideia criada', $ideaId > 0);
    Idea::update($ideaId, $idA, ['title' => 'Ideia 1 editada', 'description' => 'desc', 'category' => 'Educativo', 'platform' => 'Instagram']);
    check('ideia editada', Idea::find($ideaId, $idA)['title'] === 'Ideia 1 editada');
    check('pesquisa encontra a ideia', count(Idea::listAll($idA, 'editada')) === 1);

    echo "\nProjetos, roteiros e publicações\n";
    $projId = Project::create($idA, ['idea_id' => $ideaId, 'title' => 'Projeto 1', 'description' => null, 'platform' => 'YouTube', 'format' => 'Vídeo longo', 'status' => 'em_andamento']);
    check('projeto criado e vinculado à ideia', Project::find($projId, $idA)['idea_id'] == $ideaId);
    check('projeto em andamento é contado', Project::countByStatus($idA, 'em_andamento') === 1);
    $scrId = Script::create($idA, ['project_id' => $projId, 'title' => 'Roteiro 1', 'content' => "Linha 1\nLinha 2 — acentuação ok"]);
    check('roteiro criado e vinculado ao projeto', count(Script::byProject($projId, $idA)) === 1);
    $pubId = Publication::create($idA, ['title' => 'Post 1', 'platform' => 'Instagram', 'publish_date' => date('Y-m-d', strtotime('+3 days')), 'publish_time' => '10:30:00']);
    check('publicação criada e aparece em "próximas"', count(Publication::upcoming($idA, 5)) === 1);

    echo "\nPersistência (nova conexão, como após sair e entrar)\n";
    $c = config('db');
    $pdo2 = new PDO("mysql:host={$c['host']};port={$c['port']};dbname={$c['name']};charset={$c['charset']}", $c['user'], $c['pass']);
    $q = $pdo2->prepare('SELECT (SELECT COUNT(*) FROM ideas WHERE user_id=?) + (SELECT COUNT(*) FROM projects WHERE user_id=?) + (SELECT COUNT(*) FROM scripts WHERE user_id=?) + (SELECT COUNT(*) FROM publications WHERE user_id=?)');
    $q->execute([$idA, $idA, $idA, $idA]);
    check('os 4 registros estão gravados no MySQL', (int)$q->fetchColumn() === 4);

    echo "\nIsolamento entre usuários\n";
    check('B não vê a ideia de A (find)', Idea::find($ideaId, $idB) === null);
    check('B não vê o projeto de A', Project::find($projId, $idB) === null);
    check('B não vê o roteiro de A', Script::find($scrId, $idB) === null);
    check('B não vê a publicação de A', Publication::find($pubId, $idB) === null);
    check('listas de B estão vazias', !Idea::listAll($idB) && !Project::listAll($idB) && !Script::listAll($idB) && !Publication::listAll($idB));
    check('B não enxerga ideias de A nos selects', Idea::options($idB) === []);
    Idea::update($ideaId, $idB, ['title' => 'INVADIDA']);
    check('B não consegue editar dado de A', Idea::find($ideaId, $idA)['title'] === 'Ideia 1 editada');
    Idea::delete($ideaId, $idB); Project::delete($projId, $idB); Script::delete($scrId, $idB); Publication::delete($pubId, $idB);
    check('B não consegue excluir dado de A', Idea::find($ideaId, $idA) && Project::find($projId, $idA) && Script::find($scrId, $idA) && Publication::find($pubId, $idA));

    echo "\nRelacionamentos e exclusão\n";
    Idea::delete($ideaId, $idA);
    check('excluir ideia mantém o projeto e zera idea_id', Project::find($projId, $idA) && Project::find($projId, $idA)['idea_id'] === null);
    Script::update($scrId, $idA, ['title' => 'Roteiro 1 editado']);
    check('roteiro editado', Script::find($scrId, $idA)['title'] === 'Roteiro 1 editado');
    Publication::delete($pubId, $idA);
    check('publicação excluída', Publication::find($pubId, $idA) === null);
    Project::delete($projId, $idA);
    check('excluir projeto apaga os roteiros (CASCADE)', Script::find($scrId, $idA) === null);
} catch (Throwable $e) {
    $fail++;
    echo "\n  [ERRO] " . $e->getMessage() . ($e->getPrevious() ? ' | ' . $e->getPrevious()->getMessage() : '') . PHP_EOL;
    echo "         Confira se o MySQL está ativo, se database/database.sql foi importado e as credenciais em app/config/database.php.\n";
} finally {
    // limpeza: remove os usuários de teste (as demais linhas saem por ON DELETE CASCADE)
    try {
        foreach ([$emailA, $emailB] as $em) { Database::run('DELETE FROM users WHERE email = ?', [$em]); }
        $left = (int)Database::run('SELECT COUNT(*) FROM users WHERE email IN (?, ?)', [$emailA, $emailB])->fetchColumn();
        echo "\nLimpeza: " . ($left === 0 ? 'dados de teste removidos.' : 'ATENÇÃO: sobraram usuários de teste.') . PHP_EOL;
    } catch (Throwable $e) { /* sem conexão: nada a limpar */ }
}

echo "\nResultado: $ok OK, $fail falha(s)\n";
exit($fail ? 1 : 0);
