# REDES — Planejamento de conteúdo para redes sociais (MVP)

PHP 8+ · MySQL · PDO · Bootstrap 5 · arquitetura MVC (sem frameworks).

## Instalação no XAMPP (Windows)

1. Instale o XAMPP com **PHP 8.0 ou superior** e abra o *XAMPP Control Panel*.
2. Inicie **Apache** e **MySQL**.
3. Copie a pasta `redes` para `C:\xampp\htdocs\redes`.
4. Crie o banco:
   - Acesse http://localhost/phpmyadmin → aba **Importar** → selecione `database/database.sql` → **Importar**.
   - (ou pelo terminal: `C:\xampp\mysql\bin\mysql -u root < C:\xampp\htdocs\redes\database\database.sql`)
5. Confira `app/config/database.php` (host, banco, usuário e senha). O padrão do XAMPP já funciona (usuário `root`, senha vazia, banco `redes`).
6. Garanta que o `mod_rewrite` está ativo (padrão no XAMPP) e que `AllowOverride All` está habilitado para o `htdocs`
   (em `C:\xampp\apache\conf\httpd.conf`, bloco `<Directory "C:/xampp/htdocs">`; no XAMPP padrão já vem assim).
7. Acesse **http://localhost/redes/**: a página inicial (landing) aparece para visitantes; clique em **Começar agora** para criar sua conta ou em **Entrar** para fazer login. Usuários já logados vão direto ao dashboard.

> Não há conta demonstrativa nem dados fictícios: cada usuário começa com tudo vazio.
> As bibliotecas Bootstrap e Bootstrap Icons são carregadas via CDN (é necessário acesso à internet).

## Estrutura

```
redes/
├── .htaccess                  # encaminha tudo para /public
├── app/
│   ├── config/  config.php, database.php (conexão MySQL), routes.php
│   ├── core/    Router, Controller, CrudController, Model, Database, Auth, Csrf, Validator, helpers
│   ├── models/  User, Idea, Project, Script, Publication
│   ├── controllers/  Home, Auth, Dashboard, Idea, Project, Script, Publication, Profile
│   └── views/   layouts, auth, dashboard, crud (index/form/show), publications, profile, errors
├── database/database.sql      # cria o banco `redes` e as 5 tabelas
├── tests/smoke_test.php       # teste do banco via terminal (opcional)
└── public/      index.php (front controller), .htaccess, assets/css, assets/js
```

## Segurança
PDO + prepared statements · `password_hash`/`password_verify` · token CSRF em todo POST (inclusive logout e exclusão) ·
sessão com cookie HttpOnly/SameSite, `session_regenerate_id` no login · toda consulta filtra por `user_id`
(registros de outro usuário retornam 404) · selects de vínculo (ideia/projeto) só listam registros do próprio usuário ·
saída escapada com `htmlspecialchars` · erros registrados em log, sem expor detalhes (ative `debug` só em desenvolvimento).

## Banco de dados MySQL

Padrão local (XAMPP): host `localhost` · banco `redes` · usuário `root` · senha vazia.
Para mudar, edite **somente** `app/config/database.php` (ou defina as variáveis de ambiente
`REDES_DB_HOST`, `REDES_DB_PORT`, `REDES_DB_NAME`, `REDES_DB_USER`, `REDES_DB_PASS`).

### Importar `database/database.sql` pelo phpMyAdmin
1. Com o MySQL iniciado no XAMPP, abra http://localhost/phpmyadmin.
2. Clique na aba **Importar** (no topo, sem selecionar nenhum banco).
3. Em **Escolher arquivo**, selecione `database/database.sql` e clique em **Importar** (rodapé).
4. O banco `redes` aparecerá na lista à esquerda com as tabelas `users`, `ideas`, `projects`, `scripts` e `publications`.

### Tabelas e relacionamentos
`users` 1—N `ideas`, `projects`, `scripts`, `publications` (todas com `user_id`, `ON DELETE CASCADE`);
`ideas` 1—N `projects` (`idea_id`, `ON DELETE SET NULL`); `projects` 1—N `scripts` (`project_id`, `ON DELETE CASCADE`).
O isolamento por usuário é garantido no código: toda consulta e alteração inclui `user_id` da sessão.

### Erros
Falha de conexão mostra uma tela orientando a verificar MySQL/importação/credenciais; erros de consulta mostram
mensagem genérica. Os detalhes técnicos vão para o log do PHP (`C:\xampp\apache\logs\error.log`).
Para ver o detalhe na tela durante o desenvolvimento, use `'debug' => true` em `app/config/config.php`.

## Testes

### Automático (banco, pelo terminal)
```
C:\xampp\php\php.exe C:\xampp\htdocs\redes\tests\smoke_test.php
```
Cria dois usuários temporários e verifica: cadastro, login (senha certa/errada), e-mail duplicado, criar/editar ideias,
projetos, roteiros e publicações, persistência em uma nova conexão, isolamento entre usuários (editar/excluir/listar
dados do outro), `SET NULL`/`CASCADE` nas exclusões. No fim remove os dados de teste. Saída: `[OK]`/`[FALHA]` por item.

### Manual (navegador)
1. Cadastre o usuário A em `/register` → você cai no dashboard.
2. Crie uma ideia, edite-a, crie um projeto vinculado a ela, um roteiro no projeto e uma publicação.
3. Clique em **Sair**, entre de novo com A: tudo deve continuar lá (os dados vêm do MySQL).
4. Anote o ID de uma ideia de A (ex.: `/ideas/1`). Saia, cadastre o usuário B e abra `/ideas/1`: deve dar **404**.
   Faça o mesmo com `/projects/ID`, `/scripts/ID`, `/publications/ID` e as rotas `/edit`.
5. Pare o MySQL no XAMPP e recarregue o site: deve aparecer a tela "Não foi possível conectar ao banco de dados".
