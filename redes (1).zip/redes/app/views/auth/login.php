<h1 class="h5 mb-3">Entrar</h1>
<?php if (!empty($error)): ?><div class="alert alert-danger py-2"><?= e($error) ?></div><?php endif; ?>
<form method="post" action="<?= e(url('/login')) ?>" novalidate>
    <?= csrf_field() ?>
    <div class="mb-3">
        <label class="form-label" for="email">E-mail</label>
        <input class="form-control" type="email" id="email" name="email" value="<?= e($email) ?>" required autofocus autocomplete="email">
    </div>
    <div class="mb-3">
        <label class="form-label" for="password">Senha</label>
        <input class="form-control" type="password" id="password" name="password" required autocomplete="current-password">
    </div>
    <button class="btn btn-primary w-100" type="submit">Entrar</button>
</form>
<p class="text-center small mt-3 mb-0">Não tem conta? <a href="<?= e(url('/register')) ?>">Cadastre-se</a></p>
