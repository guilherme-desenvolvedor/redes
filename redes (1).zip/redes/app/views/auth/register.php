<?php
$f = function (string $n) use ($values, $errors) {
    return [e($values[$n] ?? ''), isset($errors[$n]) ? ' is-invalid' : '', isset($errors[$n]) ? '<div class="invalid-feedback">' . e($errors[$n]) . '</div>' : ''];
};
?>
<h1 class="h5 mb-3">Criar conta</h1>
<form method="post" action="<?= e(url('/register')) ?>" novalidate>
    <?= csrf_field() ?>
    <?php [$v, $c, $m] = $f('name'); ?>
    <div class="mb-3"><label class="form-label" for="name">Nome</label>
        <input class="form-control<?= $c ?>" id="name" name="name" value="<?= $v ?>" maxlength="100" required autofocus autocomplete="name"><?= $m ?></div>
    <?php [$v, $c, $m] = $f('email'); ?>
    <div class="mb-3"><label class="form-label" for="email">E-mail</label>
        <input class="form-control<?= $c ?>" type="email" id="email" name="email" value="<?= $v ?>" maxlength="150" required autocomplete="email"><?= $m ?></div>
    <?php [$v, $c, $m] = $f('password'); ?>
    <div class="mb-3"><label class="form-label" for="password">Senha <span class="text-muted small">(mínimo 8 caracteres)</span></label>
        <input class="form-control<?= $c ?>" type="password" id="password" name="password" required autocomplete="new-password"><?= $m ?></div>
    <?php [$v, $c, $m] = $f('password_confirm'); ?>
    <div class="mb-3"><label class="form-label" for="password_confirm">Confirmar senha</label>
        <input class="form-control<?= $c ?>" type="password" id="password_confirm" name="password_confirm" required autocomplete="new-password"><?= $m ?></div>
    <button class="btn btn-primary w-100" type="submit">Criar conta</button>
</form>
<p class="text-center small mt-3 mb-0">Já tem conta? <a href="<?= e(url('/login')) ?>">Entrar</a></p>
