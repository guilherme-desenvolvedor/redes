<?php $title = 'Página não encontrada'; ?>
<div class="text-center py-4">
    <div class="display-4 text-muted"><i class="bi bi-compass"></i></div>
    <h1 class="h4 mt-2">Página não encontrada</h1>
    <p class="text-muted">O endereço não existe ou o registro não pertence à sua conta.</p>
    <a class="btn btn-primary" href="<?= e(url('/dashboard')) ?>">Ir para o início</a>
</div>
