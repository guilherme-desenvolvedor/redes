<?php $title = 'Erro interno'; ?>
<div class="text-center py-4">
    <div class="display-4 text-danger"><i class="bi bi-exclamation-octagon"></i></div>
    <h1 class="h4 mt-2">Algo deu errado</h1>
    <p class="text-muted">Tivemos um problema ao processar sua solicitação. Verifique se o MySQL está ativo e o banco foi importado.</p>
    <?php if (!empty($detail)): ?><pre class="text-start small bg-light p-2 rounded"><?= e($detail) ?></pre><?php endif; ?>
    <a class="btn btn-primary" href="<?= e(url('/')) ?>">Tentar novamente</a>
</div>
