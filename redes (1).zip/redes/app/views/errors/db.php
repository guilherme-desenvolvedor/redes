<?php $title = 'Banco de dados indisponível'; ?>
<div class="text-center py-2">
    <div class="display-4 text-danger"><i class="bi bi-database-x"></i></div>
    <h1 class="h5 mt-2">Não foi possível conectar ao banco de dados</h1>
    <p class="text-muted small">Verifique se:</p>
    <ul class="text-start small text-muted">
        <li>o <strong>MySQL</strong> está iniciado no painel do XAMPP;</li>
        <li>o arquivo <code>database/database.sql</code> foi importado (banco <code>redes</code>);</li>
        <li>host, usuário e senha estão corretos em <code>app/config/database.php</code>.</li>
    </ul>
    <?php if (!empty($detail)): ?><pre class="text-start small bg-light p-2 rounded"><?= e($detail) ?></pre><?php endif; ?>
    <a class="btn btn-primary" href="<?= e(url('/')) ?>">Tentar novamente</a>
</div>
