<?php $title = 'Sessão expirada'; ?>
<div class="text-center py-4">
    <div class="display-4 text-warning"><i class="bi bi-shield-exclamation"></i></div>
    <h1 class="h4 mt-2">Não foi possível validar a solicitação</h1>
    <p class="text-muted">O formulário expirou. Volte, recarregue a página e tente novamente.</p>
    <a class="btn btn-primary" href="<?= e(url('/')) ?>">Voltar ao início</a>
</div>
