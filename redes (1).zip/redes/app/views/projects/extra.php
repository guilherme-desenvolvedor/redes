<div class="card"><div class="card-body">
    <div class="d-flex justify-content-between align-items-center mb-3">
        <h2 class="h6 mb-0">Roteiros deste projeto</h2>
        <a class="btn btn-sm btn-outline-primary" href="<?= e(url('/scripts/create?project_id=' . (int)$item['id'])) ?>"><i class="bi bi-plus-lg"></i> Novo roteiro</a>
    </div>
    <?php if (!$scripts): ?><p class="text-muted mb-0">Nenhum roteiro vinculado ainda.</p>
    <?php else: ?><ul class="list-group list-group-flush">
        <?php foreach ($scripts as $s): ?>
            <li class="list-group-item px-0 d-flex justify-content-between align-items-center">
                <a class="text-decoration-none" href="<?= e(url('/scripts/' . $s['id'])) ?>"><?= e($s['title']) ?></a>
                <span class="small text-muted"><?= e(fmt_date($s['updated_at'])) ?></span>
            </li>
        <?php endforeach; ?></ul>
    <?php endif; ?>
</div></div>
