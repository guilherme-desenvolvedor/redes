<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?= e($title ?? 'REDES') ?> · REDES</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css" rel="stylesheet">
    <link href="<?= e(asset('css/style.css')) ?>" rel="stylesheet">
</head>
<body class="auth-body">
<div class="auth-wrap">
    <div class="text-center mb-4"><a class="brand brand-lg" href="<?= e(url('/')) ?>">RE<span>DES</span></a>
        <div class="text-muted small">Organize e planeje seus conteúdos para redes sociais</div></div>
    <div class="card auth-card shadow-sm"><div class="card-body p-4">
        <?= flash_render() ?>
        <?= $content ?>
    </div></div>
    <p class="text-center small mt-3 mb-0"><a class="text-muted text-decoration-none" href="<?= e(url('/')) ?>"><i class="bi bi-arrow-left"></i> Voltar ao início</a></p>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script src="<?= e(asset('js/app.js')) ?>"></script>
</body>
</html>
