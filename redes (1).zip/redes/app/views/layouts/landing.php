<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="REDES reúne ferramentas para organizar ideias, planejar conteúdos e desenvolver roteiros em um só lugar.">
    <title><?= e($title ?? 'REDES') ?> · REDES</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css" rel="stylesheet">
    <link href="<?= e(asset('css/style.css')) ?>" rel="stylesheet">
    <link href="<?= e(asset('css/landing.css')) ?>" rel="stylesheet">
</head>
<body class="landing">
<header class="lp-nav navbar navbar-expand-lg sticky-top">
    <div class="container">
        <a class="brand brand-lg me-4" href="<?= e(url('/')) ?>">RE<span>DES</span></a>
        <button class="navbar-toggler border-0 shadow-none" type="button" data-bs-toggle="collapse" data-bs-target="#lpMenu" aria-controls="lpMenu" aria-expanded="false" aria-label="Abrir menu">
            <i class="bi bi-list fs-1"></i>
        </button>
        <div class="collapse navbar-collapse" id="lpMenu">
            <ul class="navbar-nav me-auto gap-lg-1">
                <li class="nav-item"><a class="nav-link" href="#inicio">Início</a></li>
                <li class="nav-item"><a class="nav-link" href="#funcionalidades">Funcionalidades</a></li>
                <li class="nav-item"><a class="nav-link" href="#sobre">Sobre a plataforma</a></li>
            </ul>
            <div class="d-grid d-lg-flex gap-2 mt-3 mt-lg-0 pb-3 pb-lg-0">
                <a class="btn btn-outline-primary" href="<?= e(url('/login')) ?>">Entrar</a>
                <a class="btn btn-primary" href="<?= e(url('/register')) ?>">Começar agora</a>
            </div>
        </div>
    </div>
</header>

<?= $content ?>

<footer class="lp-footer">
    <div class="container">
        <div class="row g-4 align-items-start">
            <div class="col-12 col-md-6">
                <span class="brand brand-lg">RE<span>DES</span></span>
                <p class="text-muted mt-2 mb-0 footer-desc">Ideias, projetos, roteiros e calendário editorial reunidos em um só lugar.</p>
            </div>
            <div class="col-6 col-md-3">
                <h2 class="h6">Navegação</h2>
                <ul class="list-unstyled mb-0 footer-links">
                    <li><a href="#inicio">Início</a></li>
                    <li><a href="#funcionalidades">Funcionalidades</a></li>
                    <li><a href="#sobre">Sobre a plataforma</a></li>
                </ul>
            </div>
            <div class="col-6 col-md-3">
                <h2 class="h6">Acesso</h2>
                <ul class="list-unstyled mb-0 footer-links">
                    <li><a href="<?= e(url('/login')) ?>">Entrar</a></li>
                    <li><a href="<?= e(url('/register')) ?>">Cadastrar</a></li>
                </ul>
            </div>
        </div>
        <hr>
        <p class="small text-muted mb-0">&copy; <?= date('Y') ?> REDES. Todos os direitos reservados.</p>
    </div>
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script src="<?= e(asset('js/app.js')) ?>"></script>
<script src="<?= e(asset('js/landing.js')) ?>"></script>
</body>
</html>
