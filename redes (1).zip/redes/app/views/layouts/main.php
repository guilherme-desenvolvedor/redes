<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?= e($title ?? 'REDES') ?> · REDES</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css" rel="stylesheet">
    <link href="<?= e(asset('css/style.css')) ?>" rel="stylesheet">
</head>
<body>
<nav class="topbar d-lg-none">
    <button class="btn btn-link text-white p-0" type="button" data-bs-toggle="offcanvas" data-bs-target="#sidebar" aria-controls="sidebar" aria-label="Abrir menu">
        <i class="bi bi-list fs-2"></i>
    </button>
    <span class="brand">RE<span>DES</span></span>
</nav>

<div class="app">
    <aside class="sidebar offcanvas-lg offcanvas-start" tabindex="-1" id="sidebar" aria-label="Menu lateral">
        <div class="offcanvas-header d-lg-none">
            <span class="brand">RE<span>DES</span></span>
            <button type="button" class="btn-close btn-close-white" data-bs-dismiss="offcanvas" data-bs-target="#sidebar" aria-label="Fechar"></button>
        </div>
        <div class="sidebar-inner">
            <a href="<?= e(url('/dashboard')) ?>" class="brand d-none d-lg-block mb-4">RE<span>DES</span></a>
            <ul class="nav flex-column gap-1">
                <li><a class="nav-link<?= nav_active('/dashboard') ?>" href="<?= e(url('/dashboard')) ?>"><i class="bi bi-speedometer2"></i> Dashboard</a></li>
                <li><a class="nav-link<?= nav_active('/ideas') ?>" href="<?= e(url('/ideas')) ?>"><i class="bi bi-lightbulb"></i> Banco de ideias</a></li>
                <li><a class="nav-link<?= nav_active('/projects') ?>" href="<?= e(url('/projects')) ?>"><i class="bi bi-kanban"></i> Projetos</a></li>
                <li><a class="nav-link<?= nav_active('/scripts') ?>" href="<?= e(url('/scripts')) ?>"><i class="bi bi-journal-text"></i> Roteiros</a></li>
                <li><a class="nav-link<?= nav_active('/publications') ?>" href="<?= e(url('/publications')) ?>"><i class="bi bi-calendar-event"></i> Calendário</a></li>
                <li><a class="nav-link<?= nav_active('/profile') ?>" href="<?= e(url('/profile')) ?>"><i class="bi bi-person-circle"></i> Perfil</a></li>
            </ul>
            <div class="sidebar-user mt-auto">
                <div class="small text-white-50 mb-2 text-truncate"><i class="bi bi-person"></i> <?= e(Auth::name()) ?></div>
                <form method="post" action="<?= e(url('/logout')) ?>">
                    <?= csrf_field() ?>
                    <button class="btn btn-outline-light btn-sm w-100" type="submit"><i class="bi bi-box-arrow-left"></i> Sair</button>
                </form>
            </div>
        </div>
    </aside>

    <main class="content">
        <?= flash_render() ?>
        <?= $content ?>
    </main>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script src="<?= e(asset('js/app.js')) ?>"></script>
</body>
</html>
