<div class="page-head"><h1 class="h3 mb-0"><i class="bi bi-person-circle"></i> Meu perfil</h1></div>
<div class="row g-3">
    <div class="col-12 col-lg-6"><div class="card h-100"><div class="card-body">
        <h2 class="h6 mb-3">Informações básicas</h2>
        <form method="post" action="<?= e(url('/profile')) ?>" novalidate>
            <?= csrf_field() ?>
            <div class="mb-3"><label class="form-label" for="email">E-mail</label>
                <input class="form-control" id="email" value="<?= e($user['email']) ?>" disabled></div>
            <div class="mb-3"><label class="form-label" for="name">Nome</label>
                <input class="form-control<?= isset($errors['name']) ? ' is-invalid' : '' ?>" id="name" name="name" maxlength="100" value="<?= e($user['name']) ?>" required>
                <?php if (isset($errors['name'])): ?><div class="invalid-feedback"><?= e($errors['name']) ?></div><?php endif; ?></div>
            <div class="mb-3"><label class="form-label" for="bio">Sobre você</label>
                <textarea class="form-control<?= isset($errors['bio']) ? ' is-invalid' : '' ?>" id="bio" name="bio" rows="3" maxlength="255" placeholder="Ex.: criador de conteúdo, nicho, objetivos"><?= e($user['bio'] ?? '') ?></textarea>
                <?php if (isset($errors['bio'])): ?><div class="invalid-feedback"><?= e($errors['bio']) ?></div><?php endif; ?></div>
            <button class="btn btn-primary" type="submit"><i class="bi bi-check-lg"></i> Salvar alterações</button>
        </form>
    </div></div></div>

    <div class="col-12 col-lg-6"><div class="card h-100"><div class="card-body">
        <h2 class="h6 mb-3">Alterar senha</h2>
        <form method="post" action="<?= e(url('/profile/password')) ?>" novalidate>
            <?= csrf_field() ?>
            <?php foreach ([['current_password', 'Senha atual', 'current-password'], ['new_password', 'Nova senha (mínimo 8 caracteres)', 'new-password'], ['new_password_confirm', 'Confirmar nova senha', 'new-password']] as [$n, $l, $ac]): ?>
            <div class="mb-3"><label class="form-label" for="<?= $n ?>"><?= e($l) ?></label>
                <input class="form-control<?= isset($pwErrors[$n]) ? ' is-invalid' : '' ?>" type="password" id="<?= $n ?>" name="<?= $n ?>" autocomplete="<?= $ac ?>" required>
                <?php if (isset($pwErrors[$n])): ?><div class="invalid-feedback"><?= e($pwErrors[$n]) ?></div><?php endif; ?></div>
            <?php endforeach; ?>
            <button class="btn btn-primary" type="submit"><i class="bi bi-key"></i> Alterar senha</button>
        </form>
    </div></div></div>
</div>
