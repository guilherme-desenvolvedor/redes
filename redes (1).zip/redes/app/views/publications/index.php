<?php
$today = date('Y-m-d');
$upcoming = []; $past = [];
foreach ($items as $it) {
    if ($it['publish_date'] >= $today) $upcoming[$it['publish_date']][] = $it;
    else $past[$it['publish_date']][] = $it;
}
krsort($past); // anteriores: mais recentes primeiro

$renderGroups = function (array $groups) use ($base, $singular) {
    foreach ($groups as $date => $list): ?>
        <div class="card mb-3">
            <div class="card-header bg-white fw-semibold"><i class="bi bi-calendar3"></i> <?= e(fmt_date_long($date)) ?><?= $date === date('Y-m-d') ? ' <span class="badge text-bg-primary ms-1">Hoje</span>' : '' ?></div>
            <ul class="list-group list-group-flush">
            <?php foreach ($list as $p): ?>
                <li class="list-group-item d-flex flex-wrap justify-content-between align-items-center gap-2">
                    <div class="d-flex align-items-center gap-3">
                        <span class="time-pill"><?= e(substr($p['publish_time'], 0, 5)) ?></span>
                        <div><a class="fw-semibold text-decoration-none" href="<?= e(url("/$base/{$p['id']}")) ?>"><?= e($p['title']) ?></a>
                        <div class="small"><span class="badge text-bg-light border"><?= e($p['platform']) ?></span></div></div>
                    </div>
                    <div class="text-nowrap">
                        <a class="btn btn-sm btn-outline-primary" href="<?= e(url("/$base/{$p['id']}/edit")) ?>" title="Editar"><i class="bi bi-pencil"></i></a>
                        <form class="d-inline" method="post" action="<?= e(url("/$base/{$p['id']}/delete")) ?>" data-confirm="Excluir esta publicação?">
                            <?= csrf_field() ?>
                            <button class="btn btn-sm btn-outline-danger" type="submit" title="Excluir"><i class="bi bi-trash"></i></button>
                        </form>
                    </div>
                </li>
            <?php endforeach; ?>
            </ul>
        </div>
    <?php endforeach;
};
?>
<div class="page-head">
    <h1 class="h3 mb-0"><i class="bi <?= e($icon) ?>"></i> <?= e($title) ?></h1>
    <a class="btn btn-primary" href="<?= e(url("/$base/create")) ?>"><i class="bi bi-plus-lg"></i> Nova publicação</a>
</div>

<form class="mb-3" method="get" action="<?= e(url("/$base")) ?>">
    <div class="input-group">
        <input class="form-control" type="search" name="q" value="<?= e($q) ?>" placeholder="Pesquisar por título ou plataforma..." aria-label="Pesquisar">
        <button class="btn btn-outline-secondary" type="submit"><i class="bi bi-search"></i></button>
        <?php if ($q !== ''): ?><a class="btn btn-outline-secondary" href="<?= e(url("/$base")) ?>">Limpar</a><?php endif; ?>
    </div>
</form>

<?php if (!$items): ?>
    <div class="card"><div class="card-body text-center text-muted p-5">
        <?php if ($q !== ''): ?>Nenhum resultado para "<?= e($q) ?>".
        <?php else: ?>Nenhuma publicação cadastrada. <a href="<?= e(url("/$base/create")) ?>">Agende sua primeira publicação</a>.<?php endif; ?>
    </div></div>
<?php else: ?>
    <h2 class="h6 text-uppercase text-muted mb-3">Próximas</h2>
    <?php if ($upcoming) $renderGroups($upcoming); else: ?><p class="text-muted">Nenhuma publicação futura.</p><?php endif; ?>
    <?php if ($past): ?>
        <h2 class="h6 text-uppercase text-muted mt-4 mb-3">Anteriores</h2>
        <?php $renderGroups($past); ?>
    <?php endif; ?>
<?php endif; ?>
