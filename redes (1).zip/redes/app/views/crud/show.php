<div class="page-head">
    <h1 class="h3 mb-0"><?= e($item['title']) ?></h1>
    <div class="d-flex gap-2">
        <a class="btn btn-outline-secondary" href="<?= e(url("/$base")) ?>"><i class="bi bi-arrow-left"></i> Voltar</a>
        <a class="btn btn-primary" href="<?= e(url("/$base/{$item['id']}/edit")) ?>"><i class="bi bi-pencil"></i> Editar</a>
        <form method="post" action="<?= e(url("/$base/{$item['id']}/delete")) ?>" data-confirm="Excluir esta <?= e($singular) ?>? Esta ação não pode ser desfeita.">
            <?= csrf_field() ?>
            <button class="btn btn-outline-danger" type="submit"><i class="bi bi-trash"></i> Excluir</button>
        </form>
    </div>
</div>

<div class="card mb-3"><div class="card-body">
    <dl class="row mb-0">
    <?php foreach ($rows as $r): ?>
        <dt class="col-sm-3"><?= e($r['label']) ?></dt>
        <dd class="col-sm-9"><?= $r['multiline'] ? nl2br(e($r['value'])) : e($r['value']) ?></dd>
    <?php endforeach; ?>
    </dl>
</div></div>

<?php if (!empty($extraView)) require VIEW_PATH . '/' . $extraView . '.php'; ?>
