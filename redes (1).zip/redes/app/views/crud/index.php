<div class="page-head">
    <h1 class="h3 mb-0"><i class="bi <?= e($icon) ?>"></i> <?= e($title) ?></h1>
    <a class="btn btn-primary" href="<?= e(url("/$base/create")) ?>"><i class="bi bi-plus-lg"></i> Nova <?= e($singular) ?></a>
</div>

<?php if ($searchable): ?>
<form class="mb-3" method="get" action="<?= e(url("/$base")) ?>">
    <div class="input-group">
        <input class="form-control" type="search" name="q" value="<?= e($q) ?>" placeholder="Pesquisar..." aria-label="Pesquisar">
        <button class="btn btn-outline-secondary" type="submit"><i class="bi bi-search"></i></button>
        <?php if ($q !== ''): ?><a class="btn btn-outline-secondary" href="<?= e(url("/$base")) ?>">Limpar</a><?php endif; ?>
    </div>
</form>
<?php endif; ?>

<div class="card"><div class="card-body p-0">
<?php if (!$items): ?>
    <div class="text-center text-muted p-5">
        <?php if ($q !== ''): ?>Nenhum resultado para "<?= e($q) ?>".
        <?php else: ?>Nada por aqui ainda. <a href="<?= e(url("/$base/create")) ?>">Cadastre sua primeira <?= e($singular) ?></a>.<?php endif; ?>
    </div>
<?php else: ?>
    <div class="table-responsive">
    <table class="table table-hover align-middle mb-0 table-cards">
        <thead><tr>
            <?php foreach ($columns as $c): ?><th><?= e($c['label']) ?></th><?php endforeach; ?>
            <th class="text-end">Ações</th>
        </tr></thead>
        <tbody>
        <?php foreach ($items as $row): ?>
            <tr>
                <?php foreach ($columns as $c): ?><td data-label="<?= e($c['label']) ?>"><?= cell($c, $row, $base) ?></td><?php endforeach; ?>
                <td class="text-end text-nowrap cell-actions">
                    <a class="btn btn-sm btn-outline-secondary" href="<?= e(url("/$base/{$row['id']}")) ?>" title="Ver"><i class="bi bi-eye"></i></a>
                    <a class="btn btn-sm btn-outline-primary" href="<?= e(url("/$base/{$row['id']}/edit")) ?>" title="Editar"><i class="bi bi-pencil"></i></a>
                    <form class="d-inline" method="post" action="<?= e(url("/$base/{$row['id']}/delete")) ?>" data-confirm="Excluir esta <?= e($singular) ?>? Esta ação não pode ser desfeita.">
                        <?= csrf_field() ?>
                        <button class="btn btn-sm btn-outline-danger" type="submit" title="Excluir"><i class="bi bi-trash"></i></button>
                    </form>
                </td>
            </tr>
        <?php endforeach; ?>
        </tbody>
    </table>
    </div>
<?php endif; ?>
</div></div>
