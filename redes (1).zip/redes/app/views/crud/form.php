<div class="page-head">
    <h1 class="h3 mb-0"><?= e($title) ?></h1>
    <a class="btn btn-outline-secondary" href="<?= e(url($item ? "/$base/{$item['id']}" : "/$base")) ?>">Cancelar</a>
</div>

<div class="card"><div class="card-body">
<form method="post" action="<?= e($action) ?>" novalidate>
    <?= csrf_field() ?>
    <div class="row g-3">
    <?php foreach ($fields as $f):
        $n = $f['name']; $t = $f['type']; $val = $values[$n] ?? '';
        if ($t === 'time' && $val !== '') $val = substr((string)$val, 0, 5);
        $err = $errors[$n] ?? null;
        $cls = 'form-control' . ($err ? ' is-invalid' : '');
    ?>
        <div class="col-12 col-md-<?= (int)($f['col'] ?? 12) ?>">
            <label class="form-label" for="f_<?= e($n) ?>"><?= e($f['label']) ?><?= !empty($f['required']) ? ' <span class="text-danger">*</span>' : '' ?></label>
            <?php if ($t === 'textarea'): ?>
                <textarea class="<?= $cls ?>" id="f_<?= e($n) ?>" name="<?= e($n) ?>" rows="<?= (int)($f['rows'] ?? 4) ?>"><?= e($val) ?></textarea>
            <?php elseif ($t === 'select'): ?>
                <select class="<?= str_replace('form-control', 'form-select', $cls) ?>" id="f_<?= e($n) ?>" name="<?= e($n) ?>">
                    <option value=""><?= e($f['empty'] ?? 'Selecione') ?></option>
                    <?php foreach ($f['options'] as $k => $label): ?>
                        <option value="<?= e($k) ?>"<?= (string)$val === (string)$k ? ' selected' : '' ?>><?= e($label) ?></option>
                    <?php endforeach; ?>
                </select>
                <?php if (!$f['options'] && !empty($f['hint_empty'])): ?>
                    <div class="form-text text-warning-emphasis"><?= e($f['hint_empty']) ?> <a href="<?= e(url('/projects/create')) ?>">Criar projeto</a></div>
                <?php endif; ?>
            <?php else: ?>
                <input class="<?= $cls ?>" type="<?= e($t) ?>" id="f_<?= e($n) ?>" name="<?= e($n) ?>" value="<?= e($val) ?>"
                    <?= !empty($f['max']) ? 'maxlength="' . (int)$f['max'] . '"' : '' ?>
                    <?= !empty($f['placeholder']) ? 'placeholder="' . e($f['placeholder']) . '"' : '' ?>>
            <?php endif; ?>
            <?php if ($err): ?><div class="invalid-feedback d-block"><?= e($err) ?></div><?php endif; ?>
        </div>
    <?php endforeach; ?>
    </div>
    <div class="mt-4 d-flex gap-2">
        <button class="btn btn-primary" type="submit"><i class="bi bi-check-lg"></i> Salvar</button>
        <a class="btn btn-outline-secondary" href="<?= e(url($item ? "/$base/{$item['id']}" : "/$base")) ?>">Cancelar</a>
    </div>
</form>
</div></div>
