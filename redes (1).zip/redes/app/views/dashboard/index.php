<div class="page-head">
    <div><h1 class="h3 mb-1">Olá, <?= e(Auth::name()) ?>!</h1>
    <p class="text-muted mb-0">Veja o panorama dos seus conteúdos.</p></div>
</div>

<div class="row g-3 mb-4">
    <div class="col-12 col-md-4"><a class="text-decoration-none" href="<?= e(url('/ideas')) ?>"><div class="card stat-card h-100"><div class="card-body d-flex align-items-center gap-3">
        <div class="stat-icon bg-warning-subtle text-warning-emphasis"><i class="bi bi-lightbulb"></i></div>
        <div><div class="stat-value"><?= (int)$ideasCount ?></div><div class="text-muted small">Ideias cadastradas</div></div></div></div></a></div>
    <div class="col-12 col-md-4"><a class="text-decoration-none" href="<?= e(url('/projects')) ?>"><div class="card stat-card h-100"><div class="card-body d-flex align-items-center gap-3">
        <div class="stat-icon bg-primary-subtle text-primary-emphasis"><i class="bi bi-kanban"></i></div>
        <div><div class="stat-value"><?= (int)$activeCount ?></div><div class="text-muted small">Projetos em andamento</div></div></div></div></a></div>
    <div class="col-12 col-md-4"><a class="text-decoration-none" href="<?= e(url('/scripts')) ?>"><div class="card stat-card h-100"><div class="card-body d-flex align-items-center gap-3">
        <div class="stat-icon bg-success-subtle text-success-emphasis"><i class="bi bi-journal-text"></i></div>
        <div><div class="stat-value"><?= (int)$scriptsCount ?></div><div class="text-muted small">Roteiros escritos</div></div></div></div></a></div>
</div>

<div class="card mb-4"><div class="card-body">
    <h2 class="h6 mb-3">Atalhos</h2>
    <div class="d-flex flex-wrap gap-2">
        <a class="btn btn-outline-primary" href="<?= e(url('/ideas/create')) ?>"><i class="bi bi-plus-lg"></i> Nova ideia</a>
        <a class="btn btn-outline-primary" href="<?= e(url('/projects/create')) ?>"><i class="bi bi-plus-lg"></i> Novo projeto</a>
        <a class="btn btn-outline-primary" href="<?= e(url('/scripts/create')) ?>"><i class="bi bi-plus-lg"></i> Novo roteiro</a>
        <a class="btn btn-outline-primary" href="<?= e(url('/publications/create')) ?>"><i class="bi bi-plus-lg"></i> Nova publicação</a>
    </div>
</div></div>

<div class="row g-3">
    <div class="col-12 col-xl-6"><div class="card h-100"><div class="card-body">
        <div class="d-flex justify-content-between align-items-center mb-3"><h2 class="h6 mb-0">Projetos em andamento</h2><a class="small" href="<?= e(url('/projects')) ?>">Ver todos</a></div>
        <?php if (!$active): ?>
            <p class="text-muted mb-0">Nenhum projeto em andamento. <a href="<?= e(url('/projects/create')) ?>">Criar projeto</a></p>
        <?php else: ?>
            <ul class="list-group list-group-flush">
            <?php foreach ($active as $p): ?>
                <li class="list-group-item px-0 d-flex justify-content-between align-items-center">
                    <div><a class="fw-semibold text-decoration-none" href="<?= e(url('/projects/' . $p['id'])) ?>"><?= e($p['title']) ?></a>
                    <div class="small text-muted"><?= e($p['platform']) ?> · <?= e($p['format']) ?></div></div>
                    <?= status_badge($p['status']) ?>
                </li>
            <?php endforeach; ?>
            </ul>
        <?php endif; ?>
    </div></div></div>

    <div class="col-12 col-xl-6"><div class="card h-100"><div class="card-body">
        <div class="d-flex justify-content-between align-items-center mb-3"><h2 class="h6 mb-0">Próximas publicações</h2><a class="small" href="<?= e(url('/publications')) ?>">Ver calendário</a></div>
        <?php if (!$upcoming): ?>
            <p class="text-muted mb-0">Nenhuma publicação agendada. <a href="<?= e(url('/publications/create')) ?>">Agendar publicação</a></p>
        <?php else: ?>
            <ul class="list-group list-group-flush">
            <?php foreach ($upcoming as $b): ?>
                <li class="list-group-item px-0 d-flex justify-content-between align-items-center">
                    <div><a class="fw-semibold text-decoration-none" href="<?= e(url('/publications/' . $b['id'])) ?>"><?= e($b['title']) ?></a>
                    <div class="small text-muted"><?= e($b['platform']) ?></div></div>
                    <div class="text-end small"><div class="fw-semibold"><?= e(fmt_date($b['publish_date'])) ?></div><div class="text-muted"><?= e(substr($b['publish_time'], 0, 5)) ?></div></div>
                </li>
            <?php endforeach; ?>
            </ul>
        <?php endif; ?>
    </div></div></div>
</div>
