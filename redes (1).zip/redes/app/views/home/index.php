<main>
<!-- HERO -->
<section id="inicio" class="lp-hero">
    <div class="container">
        <div class="row align-items-center g-5">
            <div class="col-12 col-lg-6 reveal">
                <span class="lp-pill"><i class="bi bi-stars"></i> Planejamento de conteúdo para redes sociais</span>
                <h1 class="lp-title mt-3">Sua criatividade merece um lugar para acontecer.</h1>
                <p class="lp-lead">O REDES reúne ferramentas para organizar ideias, planejar conteúdos e desenvolver roteiros em um só lugar.</p>
                <div class="d-grid d-sm-flex gap-2 gap-sm-3 mt-4">
                    <a class="btn btn-primary btn-lg" href="<?= e(url('/register')) ?>">Começar agora</a>
                    <a class="btn btn-outline-primary btn-lg" href="<?= e(url('/login')) ?>">Já tenho uma conta</a>
                </div>
            </div>
            <div class="col-12 col-lg-6 reveal">
                <!-- Ilustração do dashboard (apenas visual, sem dados reais) -->
                <div class="mock" role="img" aria-label="Ilustração do dashboard do REDES">
                    <div class="mock-bar"><i></i><i></i><i></i></div>
                    <div class="mock-body">
                        <div class="mock-side">
                            <b>RE<span>DES</span></b>
                            <span class="on"><i class="bi bi-speedometer2"></i></span>
                            <span><i class="bi bi-lightbulb"></i></span>
                            <span><i class="bi bi-kanban"></i></span>
                            <span><i class="bi bi-journal-text"></i></span>
                            <span><i class="bi bi-calendar-event"></i></span>
                        </div>
                        <div class="mock-main">
                            <div class="mock-stats">
                                <div><i class="bi bi-lightbulb text-warning"></i><small>Ideias</small><u></u></div>
                                <div><i class="bi bi-kanban text-primary"></i><small>Projetos</small><u></u></div>
                                <div><i class="bi bi-journal-text text-success"></i><small>Roteiros</small><u></u></div>
                            </div>
                            <div class="mock-panel">
                                <small>Próximas publicações</small>
                                <div class="mock-row"><em></em><u></u><span class="chip">Instagram</span></div>
                                <div class="mock-row"><em></em><u></u><span class="chip">YouTube</span></div>
                                <div class="mock-row"><em></em><u></u><span class="chip">TikTok</span></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- FUNCIONALIDADES -->
<section id="funcionalidades" class="lp-section">
    <div class="container">
        <div class="text-center mx-auto lp-head reveal">
            <h2 class="lp-h2">Tudo o que você precisa para criar com organização</h2>
            <p class="text-muted">Do primeiro insight à publicação planejada, em um fluxo simples.</p>
        </div>
        <div class="row g-3 g-lg-4">
            <?php foreach ([
                ['bi-lightbulb', 'warning', 'Banco de ideias', 'Organize suas ideias e nunca perca uma inspiração.'],
                ['bi-kanban', 'primary', 'Projetos', 'Transforme ideias em conteúdos organizados.'],
                ['bi-journal-text', 'success', 'Roteiros', 'Desenvolva e estruture seus conteúdos.'],
                ['bi-calendar-event', 'danger', 'Calendário editorial', 'Planeje suas próximas publicações.'],
            ] as [$icon, $color, $name, $desc]): ?>
            <div class="col-12 col-sm-6 col-lg-3 reveal">
                <div class="card feature-card h-100"><div class="card-body p-4">
                    <div class="feature-icon bg-<?= $color ?>-subtle text-<?= $color ?>-emphasis"><i class="bi <?= $icon ?>"></i></div>
                    <h3 class="h5 mt-3"><?= e($name) ?></h3>
                    <p class="text-muted mb-0"><?= e($desc) ?></p>
                </div></div>
            </div>
            <?php endforeach; ?>
        </div>
    </div>
</section>

<!-- SOBRE -->
<section id="sobre" class="lp-section lp-about">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-12 col-lg-9 text-center reveal">
                <span class="lp-pill"><i class="bi bi-heart"></i> Sobre a plataforma</span>
                <h2 class="lp-h2 mt-3">Criatividade com organização</h2>
                <p class="lp-lead mx-auto">Um espaço criado para transformar criatividade em organização e planejamento. Tenha suas ideias, projetos e conteúdos reunidos em um único ambiente.</p>
            </div>
        </div>
    </div>
</section>

<!-- CTA -->
<section class="lp-section pt-0">
    <div class="container">
        <div class="lp-cta reveal">
            <h2 class="lp-h2 text-white">Sua próxima grande ideia começa aqui.</h2>
            <p class="mb-4">Crie sua conta e experimente o REDES para organizar seus próximos conteúdos.</p>
            <a class="btn btn-light btn-lg fw-semibold" href="<?= e(url('/register')) ?>">Começar agora</a>
        </div>
    </div>
</section>
</main>
