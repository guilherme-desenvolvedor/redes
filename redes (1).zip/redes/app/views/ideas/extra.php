<div class="card"><div class="card-body">
    <div class="d-flex justify-content-between align-items-center mb-3">
        <h2 class="h6 mb-0">Projetos criados a partir desta ideia</h2>
        <a class="btn btn-sm btn-outline-primary" href="<?= e(url('/projects/create?idea_id=' . (int)$item['id'])) ?>"><i class="bi bi-plus-lg"></i> Criar projeto</a>
    </div>
    <?php if (!$projects): ?><p class="text-muted mb-0">Nenhum projeto vinculado ainda.</p>
    <?php else: ?><ul class="list-group list-group-flush">
        <?php foreach ($projects as $p): ?>
            <li class="list-group-item px-0 d-flex justify-content-between align-items-center">
                <a class="text-decoration-none" href="<?= e(url('/projects/' . $p['id'])) ?>"><?= e($p['title']) ?></a><?= status_badge($p['status']) ?>
            </li>
        <?php endforeach; ?></ul>
    <?php endif; ?>
</div></div>
