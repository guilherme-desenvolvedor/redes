<?php
class Publication extends Model
{
    protected static $table = 'publications';
    protected static $fillable = ['title', 'platform', 'publish_date', 'publish_time'];
    protected static $searchable = ['title', 'platform'];

    public static function listAll(int $uid, string $q = ''): array
    {
        $p = [$uid];
        $sql = 'SELECT * FROM publications WHERE user_id = ?' . static::searchClause($q, $p)
             . ' ORDER BY publish_date ASC, publish_time ASC, id ASC';
        return static::run($sql, $p)->fetchAll();
    }

    public static function upcoming(int $uid, int $limit = 5): array
    {
        $limit = max(1, $limit);
        $sql = "SELECT * FROM publications WHERE user_id = ? AND publish_date >= ? ORDER BY publish_date ASC, publish_time ASC LIMIT $limit";
        return static::run($sql, [$uid, date('Y-m-d')])->fetchAll();
    }
}
