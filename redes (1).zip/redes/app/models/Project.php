<?php
class Project extends Model
{
    protected static $table = 'projects';
    protected static $fillable = ['idea_id', 'title', 'description', 'platform', 'format', 'status'];
    protected static $searchable = ['p.title', 'p.description', 'p.platform', 'p.format', 'i.title'];

    public static function listAll(int $uid, string $q = ''): array
    {
        $p = [$uid];
        $sql = 'SELECT p.*, i.title AS idea_title FROM projects p LEFT JOIN ideas i ON i.id = p.idea_id WHERE p.user_id = ?'
             . static::searchClause($q, $p) . ' ORDER BY p.created_at DESC, p.id DESC';
        return static::run($sql, $p)->fetchAll();
    }

    public static function options(int $uid): array
    {
        return static::run('SELECT id, title FROM projects WHERE user_id = ? ORDER BY title', [$uid])->fetchAll(PDO::FETCH_KEY_PAIR);
    }

    public static function byStatus(int $uid, string $status, int $limit = 5): array
    {
        $limit = max(1, $limit);
        return static::run("SELECT id, title, platform, format, status FROM projects WHERE user_id = ? AND status = ? ORDER BY updated_at DESC LIMIT $limit", [$uid, $status])->fetchAll();
    }

    public static function countByStatus(int $uid, string $status): int
    {
        return (int)static::run('SELECT COUNT(*) FROM projects WHERE user_id = ? AND status = ?', [$uid, $status])->fetchColumn();
    }

    public static function byIdea(int $ideaId, int $uid): array
    {
        return static::run('SELECT id, title, status FROM projects WHERE idea_id = ? AND user_id = ? ORDER BY created_at DESC', [$ideaId, $uid])->fetchAll();
    }
}
