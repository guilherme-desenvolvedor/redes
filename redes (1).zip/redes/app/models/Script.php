<?php
class Script extends Model
{
    protected static $table = 'scripts';
    protected static $fillable = ['project_id', 'title', 'content'];
    protected static $searchable = ['s.title', 's.content', 'p.title'];

    public static function listAll(int $uid, string $q = ''): array
    {
        $p = [$uid];
        $sql = 'SELECT s.*, p.title AS project_title FROM scripts s JOIN projects p ON p.id = s.project_id WHERE s.user_id = ?'
             . static::searchClause($q, $p) . ' ORDER BY s.created_at DESC, s.id DESC';
        return static::run($sql, $p)->fetchAll();
    }

    public static function byProject(int $projectId, int $uid): array
    {
        return static::run('SELECT id, title, updated_at FROM scripts WHERE project_id = ? AND user_id = ? ORDER BY created_at DESC', [$projectId, $uid])->fetchAll();
    }
}
