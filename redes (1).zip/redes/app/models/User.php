<?php
class User
{
    public static function findByEmail(string $email): ?array
    {
        return Database::run('SELECT * FROM users WHERE email = ?', [$email])->fetch() ?: null;
    }

    public static function findById(int $id): ?array
    {
        return Database::run('SELECT * FROM users WHERE id = ?', [$id])->fetch() ?: null;
    }

    public static function create(string $name, string $email, string $password): int
    {
        Database::run('INSERT INTO users (name, email, password) VALUES (?, ?, ?)', [$name, $email, password_hash($password, PASSWORD_DEFAULT)]);
        return Database::lastId();
    }

    public static function updateProfile(int $id, string $name, ?string $bio): void
    {
        Database::run('UPDATE users SET name = ?, bio = ? WHERE id = ?', [$name, $bio, $id]);
    }

    public static function updatePassword(int $id, string $password): void
    {
        Database::run('UPDATE users SET password = ? WHERE id = ?', [password_hash($password, PASSWORD_DEFAULT), $id]);
    }
}
