<?php
class Idea extends Model
{
    protected static $table = 'ideas';
    protected static $fillable = ['title', 'description', 'category', 'platform'];
    protected static $searchable = ['title', 'description', 'category', 'platform'];

    /** [id => título] para selects (somente do usuário). */
    public static function options(int $uid): array
    {
        return static::run('SELECT id, title FROM ideas WHERE user_id = ? ORDER BY title', [$uid])->fetchAll(PDO::FETCH_KEY_PAIR);
    }
}
