<?php
class AuthController extends Controller
{
    protected bool $public = true;

    public function home(): void
    {
        $this->redirect(Auth::check() ? '/dashboard' : '/login');
    }

    public function loginForm(): void
    {
        if (Auth::check()) $this->redirect('/dashboard');
        $this->render('auth/login', ['title' => 'Entrar', 'email' => '', 'error' => null], 'auth');
    }

    public function login(): void
    {
        $this->verifyCsrf();
        $email = strtolower(trim((string)($_POST['email'] ?? '')));
        $pass = (string)($_POST['password'] ?? '');
        $user = filter_var($email, FILTER_VALIDATE_EMAIL) ? User::findByEmail($email) : null;

        if ($user && password_verify($pass, $user['password'])) {
            if (password_needs_rehash($user['password'], PASSWORD_DEFAULT)) {
                User::updatePassword((int)$user['id'], $pass);
            }
            Auth::login($user);
            $this->redirect('/dashboard');
        }
        $this->render('auth/login', ['title' => 'Entrar', 'email' => $email, 'error' => 'E-mail ou senha inválidos.'], 'auth');
    }

    public function registerForm(): void
    {
        if (Auth::check()) $this->redirect('/dashboard');
        $this->render('auth/register', ['title' => 'Criar conta', 'values' => [], 'errors' => []], 'auth');
    }

    public function register(): void
    {
        $this->verifyCsrf();
        $name = trim((string)($_POST['name'] ?? ''));
        $email = strtolower(trim((string)($_POST['email'] ?? '')));
        $pass = (string)($_POST['password'] ?? '');
        $conf = (string)($_POST['password_confirm'] ?? '');
        $errors = [];

        if (mb_strlen($name) < 2 || mb_strlen($name) > 100) $errors['name'] = 'Informe seu nome (2 a 100 caracteres).';
        if (!filter_var($email, FILTER_VALIDATE_EMAIL) || mb_strlen($email) > 150) $errors['email'] = 'Informe um e-mail válido.';
        elseif (User::findByEmail($email)) $errors['email'] = 'Este e-mail já está cadastrado.';
        if (strlen($pass) < 8) $errors['password'] = 'A senha deve ter no mínimo 8 caracteres.';
        elseif ($pass !== $conf) $errors['password_confirm'] = 'As senhas não conferem.';

        if (!$errors) {
            try {
                $id = User::create($name, $email, $pass);
            } catch (DatabaseException $e) {
                if ($e->isDuplicate()) { // e-mail duplicado (condição de corrida)
                    $errors['email'] = 'Este e-mail já está cadastrado.';
                } else {
                    throw $e;
                }
            }
        }
        if ($errors) {
            $this->render('auth/register', ['title' => 'Criar conta', 'values' => ['name' => $name, 'email' => $email], 'errors' => $errors], 'auth');
            return;
        }
        Auth::login(['id' => $id, 'name' => $name]);
        flash('success', 'Conta criada com sucesso! Bem-vindo(a) ao REDES.');
        $this->redirect('/dashboard');
    }

    public function logout(): void
    {
        $this->verifyCsrf();
        Auth::logout();
        Auth::start();
        flash('success', 'Você saiu da sua conta.');
        $this->redirect('/login');
    }
}
