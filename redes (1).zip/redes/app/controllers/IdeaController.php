<?php
class IdeaController extends CrudController
{
    protected string $model = 'Idea';
    protected string $base = 'ideas';
    protected string $singular = 'ideia';
    protected string $plural = 'Banco de ideias';
    protected string $icon = 'bi-lightbulb';
    protected string $extraView = 'ideas/extra';
    protected array $msg = ['created' => 'Ideia cadastrada com sucesso.', 'updated' => 'Ideia atualizada com sucesso.', 'deleted' => 'Ideia excluída com sucesso.'];

    protected function fields(int $uid): array
    {
        return [
            ['name' => 'title', 'label' => 'Título', 'type' => 'text', 'required' => true, 'max' => 150, 'col' => 12],
            ['name' => 'description', 'label' => 'Descrição', 'type' => 'textarea', 'max' => 3000, 'col' => 12],
            ['name' => 'category', 'label' => 'Categoria', 'type' => 'text', 'max' => 80, 'col' => 6, 'placeholder' => 'Ex.: Educativo, Bastidores, Promoção'],
            ['name' => 'platform', 'label' => 'Plataforma', 'type' => 'select', 'options' => platforms(), 'col' => 6, 'empty' => 'Selecione (opcional)'],
        ];
    }

    protected function columns(): array
    {
        return [
            ['key' => 'title', 'label' => 'Título', 'type' => 'link'],
            ['key' => 'category', 'label' => 'Categoria', 'type' => 'text'],
            ['key' => 'platform', 'label' => 'Plataforma', 'type' => 'badge'],
            ['key' => 'created_at', 'label' => 'Criada em', 'type' => 'date'],
        ];
    }

    protected function extra(array $item, int $uid): array
    {
        return ['projects' => Project::byIdea((int)$item['id'], $uid)];
    }
}
