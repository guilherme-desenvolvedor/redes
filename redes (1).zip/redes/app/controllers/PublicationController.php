<?php
class PublicationController extends CrudController
{
    protected string $model = 'Publication';
    protected string $base = 'publications';
    protected string $singular = 'publicação';
    protected string $plural = 'Calendário editorial';
    protected string $icon = 'bi-calendar-event';
    protected string $indexView = 'publications/index';
    protected array $msg = ['created' => 'Publicação cadastrada com sucesso.', 'updated' => 'Publicação atualizada com sucesso.', 'deleted' => 'Publicação excluída com sucesso.'];

    protected function fields(int $uid): array
    {
        return [
            ['name' => 'title', 'label' => 'Título', 'type' => 'text', 'required' => true, 'max' => 150, 'col' => 12],
            ['name' => 'platform', 'label' => 'Plataforma', 'type' => 'select', 'required' => true, 'options' => platforms(), 'col' => 4, 'empty' => 'Selecione'],
            ['name' => 'publish_date', 'label' => 'Data', 'type' => 'date', 'required' => true, 'col' => 4],
            ['name' => 'publish_time', 'label' => 'Horário', 'type' => 'time', 'required' => true, 'col' => 4],
        ];
    }

    protected function columns(): array
    {
        return [];
    }
}
