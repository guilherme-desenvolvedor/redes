<?php
class ScriptController extends CrudController
{
    protected string $model = 'Script';
    protected string $base = 'scripts';
    protected string $singular = 'roteiro';
    protected string $plural = 'Roteiros';
    protected string $icon = 'bi-journal-text';
    protected array $msg = ['created' => 'Roteiro criado com sucesso.', 'updated' => 'Roteiro atualizado com sucesso.', 'deleted' => 'Roteiro excluído com sucesso.'];

    protected function fields(int $uid): array
    {
        return [
            ['name' => 'project_id', 'label' => 'Projeto', 'type' => 'select', 'cast' => 'int', 'required' => true, 'options' => Project::options($uid), 'col' => 12, 'empty' => 'Selecione um projeto',
             'hint_empty' => 'Você ainda não tem projetos. Crie um projeto antes de escrever um roteiro.'],
            ['name' => 'title', 'label' => 'Título', 'type' => 'text', 'required' => true, 'max' => 150, 'col' => 12],
            ['name' => 'content', 'label' => 'Conteúdo do roteiro', 'type' => 'textarea', 'required' => true, 'max' => 20000, 'rows' => 14, 'col' => 12],
        ];
    }

    protected function columns(): array
    {
        return [
            ['key' => 'title', 'label' => 'Título', 'type' => 'link'],
            ['key' => 'project_title', 'label' => 'Projeto', 'type' => 'text'],
            ['key' => 'updated_at', 'label' => 'Atualizado em', 'type' => 'date'],
        ];
    }
}
