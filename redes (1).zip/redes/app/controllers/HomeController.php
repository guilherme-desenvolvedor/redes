<?php
/** Página inicial pública (landing page). Usuários logados vão direto ao dashboard. */
class HomeController extends Controller
{
    protected bool $public = true;

    public function index(): void
    {
        if (Auth::check()) {
            $this->redirect('/dashboard');
        }
        render_view('home/index', ['title' => 'Organize suas ideias e conteúdos'], 'landing');
    }
}
