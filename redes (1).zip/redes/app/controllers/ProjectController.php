<?php
class ProjectController extends CrudController
{
    protected string $model = 'Project';
    protected string $base = 'projects';
    protected string $singular = 'projeto';
    protected string $plural = 'Projetos';
    protected string $icon = 'bi-kanban';
    protected string $extraView = 'projects/extra';
    protected array $msg = ['created' => 'Projeto criado com sucesso.', 'updated' => 'Projeto atualizado com sucesso.', 'deleted' => 'Projeto excluído com sucesso (os roteiros vinculados também foram removidos).'];

    protected function fields(int $uid): array
    {
        return [
            ['name' => 'title', 'label' => 'Título', 'type' => 'text', 'required' => true, 'max' => 150, 'col' => 12],
            ['name' => 'idea_id', 'label' => 'Ideia vinculada', 'type' => 'select', 'cast' => 'int', 'options' => Idea::options($uid), 'col' => 12, 'empty' => 'Nenhuma ideia vinculada'],
            ['name' => 'description', 'label' => 'Descrição', 'type' => 'textarea', 'max' => 3000, 'col' => 12],
            ['name' => 'platform', 'label' => 'Plataforma', 'type' => 'select', 'required' => true, 'options' => platforms(), 'col' => 4, 'empty' => 'Selecione'],
            ['name' => 'format', 'label' => 'Formato', 'type' => 'select', 'required' => true, 'options' => formats(), 'col' => 4, 'empty' => 'Selecione'],
            ['name' => 'status', 'label' => 'Status', 'type' => 'select', 'required' => true, 'options' => statuses(), 'col' => 4, 'empty' => 'Selecione'],
        ];
    }

    protected function columns(): array
    {
        return [
            ['key' => 'title', 'label' => 'Título', 'type' => 'link'],
            ['key' => 'platform', 'label' => 'Plataforma', 'type' => 'badge'],
            ['key' => 'format', 'label' => 'Formato', 'type' => 'text'],
            ['key' => 'status', 'label' => 'Status', 'type' => 'status'],
            ['key' => 'idea_title', 'label' => 'Ideia', 'type' => 'text'],
        ];
    }

    protected function extra(array $item, int $uid): array
    {
        return ['scripts' => Script::byProject((int)$item['id'], $uid)];
    }

    public function create(): void
    {
        // valor padrão do status ao criar
        $_GET['status'] = $_GET['status'] ?? 'planejamento';
        parent::create();
    }
}
