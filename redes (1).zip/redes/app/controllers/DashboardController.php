<?php
class DashboardController extends Controller
{
    public function index(): void
    {
        $uid = Auth::id();
        $this->render('dashboard/index', [
            'title'        => 'Dashboard',
            'ideasCount'   => Idea::count($uid),
            'activeCount'  => Project::countByStatus($uid, 'em_andamento'),
            'scriptsCount' => Script::count($uid),
            'active'       => Project::byStatus($uid, 'em_andamento', 5),
            'upcoming'     => Publication::upcoming($uid, 5),
        ]);
    }
}
