<?php
class ProfileController extends Controller
{
    private function show(array $user, array $errors = [], array $pwErrors = []): void
    {
        $this->render('profile/edit', ['title' => 'Meu perfil', 'user' => $user, 'errors' => $errors, 'pwErrors' => $pwErrors]);
    }

    public function edit(): void
    {
        $user = User::findById(Auth::id()) ?? $this->notFound();
        $this->show($user);
    }

    public function update(): void
    {
        $this->verifyCsrf();
        $user = User::findById(Auth::id()) ?? $this->notFound();
        $name = trim((string)($_POST['name'] ?? ''));
        $bio = trim((string)($_POST['bio'] ?? ''));
        $errors = [];
        if (mb_strlen($name) < 2 || mb_strlen($name) > 100) $errors['name'] = 'Informe seu nome (2 a 100 caracteres).';
        if (mb_strlen($bio) > 255) $errors['bio'] = 'As informações devem ter no máximo 255 caracteres.';
        if ($errors) {
            $user['name'] = $name;
            $user['bio'] = $bio;
            $this->show($user, $errors);
            return;
        }
        User::updateProfile($user['id'], $name, $bio === '' ? null : $bio);
        $_SESSION['uname'] = $name;
        flash('success', 'Perfil atualizado com sucesso.');
        $this->redirect('/profile');
    }

    public function password(): void
    {
        $this->verifyCsrf();
        $user = User::findById(Auth::id()) ?? $this->notFound();
        $cur = (string)($_POST['current_password'] ?? '');
        $new = (string)($_POST['new_password'] ?? '');
        $conf = (string)($_POST['new_password_confirm'] ?? '');
        $errors = [];
        if (!password_verify($cur, $user['password'])) $errors['current_password'] = 'Senha atual incorreta.';
        if (strlen($new) < 8) $errors['new_password'] = 'A nova senha deve ter no mínimo 8 caracteres.';
        elseif ($new !== $conf) $errors['new_password_confirm'] = 'As senhas não conferem.';
        if ($errors) {
            $this->show($user, [], $errors);
            return;
        }
        User::updatePassword($user['id'], $new);
        session_regenerate_id(true);
        flash('success', 'Senha alterada com sucesso.');
        $this->redirect('/profile');
    }
}
