<?php
/** Model base: todas as consultas filtram por user_id (isolamento entre usuários). */
abstract class Model
{
    protected static $table = '';
    protected static $fillable = [];
    protected static $searchable = [];

    protected static function run(string $sql, array $params = []): PDOStatement
    {
        return Database::run($sql, $params);
    }

    protected static function searchClause(string $q, array &$params): string
    {
        if ($q === '' || !static::$searchable) return '';
        $like = '%' . str_replace(['|', '%', '_'], ['||', '|%', '|_'], $q) . '%';
        $parts = [];
        foreach (static::$searchable as $col) {
            $parts[] = "$col LIKE ? ESCAPE '|'";
            $params[] = $like;
        }
        return ' AND (' . implode(' OR ', $parts) . ')';
    }

    public static function listAll(int $uid, string $q = ''): array
    {
        $p = [$uid];
        $sql = 'SELECT * FROM ' . static::$table . ' WHERE user_id = ?'
             . static::searchClause($q, $p) . ' ORDER BY created_at DESC, id DESC';
        return static::run($sql, $p)->fetchAll();
    }

    public static function findDetailed(int $id, int $uid): ?array
    {
        return static::find($id, $uid);
    }

    public static function find(int $id, int $uid): ?array
    {
        $row = static::run('SELECT * FROM ' . static::$table . ' WHERE id = ? AND user_id = ?', [$id, $uid])->fetch();
        return $row ?: null;
    }

    public static function count(int $uid): int
    {
        return (int)static::run('SELECT COUNT(*) FROM ' . static::$table . ' WHERE user_id = ?', [$uid])->fetchColumn();
    }

    public static function create(int $uid, array $data): int
    {
        $cols = ['user_id'];
        $vals = [$uid];
        foreach (static::$fillable as $c) {
            if (array_key_exists($c, $data)) { $cols[] = $c; $vals[] = $data[$c]; }
        }
        $sql = 'INSERT INTO ' . static::$table . ' (' . implode(',', $cols) . ') VALUES ('
             . implode(',', array_fill(0, count($cols), '?')) . ')';
        static::run($sql, $vals);
        return Database::lastId();
    }

    public static function update(int $id, int $uid, array $data): void
    {
        $sets = [];
        $vals = [];
        foreach (static::$fillable as $c) {
            if (array_key_exists($c, $data)) { $sets[] = "$c = ?"; $vals[] = $data[$c]; }
        }
        if (!$sets) return;
        $vals[] = $id;
        $vals[] = $uid;
        static::run('UPDATE ' . static::$table . ' SET ' . implode(', ', $sets) . ' WHERE id = ? AND user_id = ?', $vals);
    }

    public static function delete(int $id, int $uid): void
    {
        static::run('DELETE FROM ' . static::$table . ' WHERE id = ? AND user_id = ?', [$id, $uid]);
    }
}
