<?php
// Funções auxiliares globais

function config(string $key)
{
    static $cfg = null;
    $cfg ??= require APP_PATH . '/config/config.php';
    return $cfg[$key] ?? null;
}

function e($v): string
{
    return htmlspecialchars((string)$v, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}

function base_url(): string
{
    static $b = null;
    if ($b === null) {
        $b = rtrim(str_replace('\\', '/', dirname($_SERVER['SCRIPT_NAME'] ?? '')), '/');
    }
    return $b;
}

function url(string $path = ''): string
{
    return base_url() . '/' . ltrim($path, '/');
}

function asset(string $path): string
{
    return base_url() . '/assets/' . ltrim($path, '/');
}

function current_path(): string
{
    return $GLOBALS['REDES_PATH'] ?? '/';
}

function nav_active(string $prefix): string
{
    $p = current_path();
    return ($p === $prefix || strpos($p, $prefix . '/') === 0) ? ' active' : '';
}

function csrf_field(): string
{
    return '<input type="hidden" name="_csrf" value="' . e(Csrf::token()) . '">';
}

function flash(string $type, string $message): void
{
    $_SESSION['flash'][] = ['type' => $type, 'message' => $message];
}

function flash_render(): string
{
    $out = '';
    foreach ($_SESSION['flash'] ?? [] as $f) {
        $cls = $f['type'] === 'error' ? 'danger' : $f['type'];
        $out .= '<div class="alert alert-' . e($cls) . ' alert-dismissible fade show" role="alert">'
              . e($f['message'])
              . '<button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Fechar"></button></div>';
    }
    unset($_SESSION['flash']);
    return $out;
}

function render_view(string $view, array $data = [], string $layout = 'main'): void
{
    extract($data, EXTR_SKIP);
    ob_start();
    require VIEW_PATH . "/$view.php";
    $content = ob_get_clean();
    require VIEW_PATH . "/layouts/$layout.php";
}

// ---------- Listas de opções ----------
function platforms(): array
{
    $l = ['Instagram', 'TikTok', 'YouTube', 'Facebook', 'LinkedIn', 'X (Twitter)', 'Pinterest', 'Blog', 'Outra'];
    return array_combine($l, $l);
}

function formats(): array
{
    $l = ['Reels', 'Carrossel', 'Post estático', 'Stories', 'Vídeo curto', 'Vídeo longo', 'Thread / texto', 'Artigo', 'Outro'];
    return array_combine($l, $l);
}

function statuses(): array
{
    return [
        'planejamento' => 'Planejamento',
        'em_andamento' => 'Em andamento',
        'concluido'    => 'Concluído',
        'pausado'      => 'Pausado',
    ];
}

function status_badge(string $status): string
{
    $colors = ['planejamento' => 'secondary', 'em_andamento' => 'primary', 'concluido' => 'success', 'pausado' => 'warning'];
    $label = statuses()[$status] ?? $status;
    return '<span class="badge text-bg-' . ($colors[$status] ?? 'secondary') . '">' . e($label) . '</span>';
}

// ---------- Formatação ----------
function fmt_date(?string $d): string
{
    if (!$d) return '';
    $dt = DateTime::createFromFormat('Y-m-d', substr($d, 0, 10));
    return $dt ? $dt->format('d/m/Y') : $d;
}

function fmt_datetime(?string $d): string
{
    if (!$d) return '';
    $dt = new DateTime($d);
    return $dt->format('d/m/Y H:i');
}

function fmt_date_long(string $d): string
{
    $dias = ['domingo', 'segunda-feira', 'terça-feira', 'quarta-feira', 'quinta-feira', 'sexta-feira', 'sábado'];
    $dt = DateTime::createFromFormat('Y-m-d', $d);
    return $dt ? ucfirst($dias[(int)$dt->format('w')]) . ', ' . $dt->format('d/m/Y') : $d;
}

function cell(array $col, array $row, string $base): string
{
    $v = $row[$col['key']] ?? null;
    if ($v === null || $v === '') return '<span class="text-muted">—</span>';
    switch ($col['type'] ?? 'text') {
        case 'link':
            return '<a class="fw-semibold text-decoration-none" href="' . e(url($base . '/' . $row['id'])) . '">' . e($v) . '</a>';
        case 'status': return status_badge((string)$v);
        case 'date':   return e(fmt_date($v));
        case 'time':   return e(substr($v, 0, 5));
        case 'badge':  return '<span class="badge text-bg-light border">' . e($v) . '</span>';
        default:       return e(mb_strimwidth((string)$v, 0, 60, '…'));
    }
}
