<?php
class Router
{
    private array $routes = [];

    public function add(string $method, string $pattern, string $handler): void
    {
        $regex = '#^' . str_replace('{id}', '(\d+)', $pattern) . '$#';
        $this->routes[] = [$method, $regex, $handler];
    }

    public static function path(): string
    {
        $p = rawurldecode(parse_url($_SERVER['REQUEST_URI'] ?? '/', PHP_URL_PATH) ?: '/');
        $base = base_url();
        if ($base !== '' && strpos($p, $base) === 0) {
            $p = substr($p, strlen($base));
        } else {
            // acesso via /redes/ (regra do .htaccess raiz)
            $parent = rtrim(str_replace('\\', '/', dirname($base)), '/');
            if ($parent !== '' && $parent !== '.' && strpos($p, $parent) === 0) {
                $p = substr($p, strlen($parent));
            }
        }
        return '/' . trim($p, '/');
    }

    public function dispatch(): void
    {
        $method = $_SERVER['REQUEST_METHOD'] ?? 'GET';
        $path = self::path();
        $GLOBALS['REDES_PATH'] = $path;

        foreach ($this->routes as [$m, $regex, $handler]) {
            if ($m === $method && preg_match($regex, $path, $matches)) {
                [$class, $action] = explode('@', $handler);
                $args = array_map('intval', array_slice($matches, 1));
                (new $class())->$action(...$args);
                return;
            }
        }
        http_response_code(404);
        render_view('errors/404', [], Auth::check() ? 'main' : 'auth');
    }
}
