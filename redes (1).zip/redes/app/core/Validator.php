<?php
class Validator
{
    /** Valida $input conforme a definição de campos. Retorna [valores, erros]. */
    public static function run(array $fields, array $input): array
    {
        $values = [];
        $errors = [];

        foreach ($fields as $f) {
            $n = $f['name'];
            $type = $f['type'] ?? 'text';
            $label = $f['label'];
            $raw = (isset($input[$n]) && is_string($input[$n])) ? $input[$n] : '';
            $raw = $type === 'textarea' ? trim(str_replace("\r\n", "\n", $raw)) : trim($raw);

            if ($raw === '') {
                if (!empty($f['required'])) $errors[$n] = "O campo \"$label\" é obrigatório.";
                $values[$n] = null;
                continue;
            }

            $values[$n] = $raw;

            if (!empty($f['max']) && mb_strlen($raw) > $f['max']) {
                $errors[$n] = "O campo \"$label\" deve ter no máximo {$f['max']} caracteres.";
                continue;
            }

            switch ($type) {
                case 'select':
                    $keys = array_map('strval', array_keys($f['options'] ?? []));
                    if (!in_array($raw, $keys, true)) {
                        $errors[$n] = "Selecione uma opção válida em \"$label\".";
                    } elseif (($f['cast'] ?? '') === 'int') {
                        $values[$n] = (int)$raw;
                    }
                    break;
                case 'date':
                    $d = DateTime::createFromFormat('!Y-m-d', $raw);
                    if (!$d || $d->format('Y-m-d') !== $raw) $errors[$n] = "Informe uma data válida em \"$label\".";
                    break;
                case 'time':
                    if (!preg_match('/^([01]\d|2[0-3]):[0-5]\d$/', $raw)) {
                        $errors[$n] = "Informe um horário válido em \"$label\".";
                    } else {
                        $values[$n] = $raw . ':00';
                    }
                    break;
            }
        }
        return [$values, $errors];
    }
}
