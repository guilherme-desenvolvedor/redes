<?php
/** Erro de banco de dados já tratado (mensagem amigável; detalhes técnicos vão para o log). */
class DatabaseException extends RuntimeException
{
    private string $sqlState;
    private bool $connection;

    public function __construct(string $message, string $sqlState = '', bool $connection = false, ?Throwable $previous = null)
    {
        parent::__construct($message, 0, $previous);
        $this->sqlState = $sqlState;
        $this->connection = $connection;
    }

    public function getSqlState(): string { return $this->sqlState; }
    public function isConnection(): bool { return $this->connection; }
    /** Violação de chave única (ex.: e-mail já cadastrado). */
    public function isDuplicate(): bool { return $this->sqlState === '23000'; }
}
