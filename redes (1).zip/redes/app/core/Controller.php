<?php
abstract class Controller
{
    /** Controllers públicos (login/cadastro) sobrescrevem para true. */
    protected bool $public = false;

    public function __construct()
    {
        if (!$this->public) Auth::requireLogin();
    }

    protected function render(string $view, array $data = [], ?string $layout = null): void
    {
        render_view($view, $data, $layout ?? (Auth::check() ? 'main' : 'auth'));
    }

    protected function redirect(string $path): void
    {
        header('Location: ' . url($path));
        exit;
    }

    protected function verifyCsrf(): void
    {
        if (!Csrf::verify($_POST['_csrf'] ?? null)) {
            http_response_code(419);
            render_view('errors/419', [], Auth::check() ? 'main' : 'auth');
            exit;
        }
    }

    protected function notFound(): void
    {
        http_response_code(404);
        $this->render('errors/404');
        exit;
    }
}
