<?php
class Database
{
    private static ?PDO $pdo = null;

    /** Conexão PDO única (lazy). Falhas viram DatabaseException sem expor credenciais. */
    public static function get(): PDO
    {
        if (self::$pdo === null) {
            $c = config('db');
            $dsn = "mysql:host={$c['host']};port={$c['port']};dbname={$c['name']};charset={$c['charset']}";
            try {
                self::$pdo = new PDO($dsn, $c['user'], $c['pass'], [
                    PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
                    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                    PDO::ATTR_EMULATE_PREPARES   => false,
                ]);
            } catch (PDOException $e) {
                error_log('[REDES][DB] Falha de conexão: ' . $e->getMessage());
                throw new DatabaseException('Não foi possível conectar ao banco de dados.', (string)$e->getCode(), true, $e);
            }
        }
        return self::$pdo;
    }

    /** Executa uma consulta preparada; erros são registrados e relançados como DatabaseException. */
    public static function run(string $sql, array $params = []): PDOStatement
    {
        $pdo = self::get();
        try {
            $stmt = $pdo->prepare($sql);
            $stmt->execute($params);
            return $stmt;
        } catch (PDOException $e) {
            error_log('[REDES][SQL] ' . $e->getMessage());
            throw new DatabaseException('Erro ao executar a operação no banco de dados.', (string)$e->getCode(), false, $e);
        }
    }

    public static function lastId(): int
    {
        return (int)self::get()->lastInsertId();
    }
}
