<?php
/** Controller genérico de CRUD escopado por usuário. Cada módulo define apenas campos e colunas. */
abstract class CrudController extends Controller
{
    protected string $model;        // classe do Model
    protected string $base;         // ex.: 'ideas'
    protected string $singular;     // ex.: 'ideia'
    protected string $plural;       // ex.: 'Ideias'
    protected string $icon = 'bi-circle';
    protected string $indexView = 'crud/index';
    protected string $extraView = '';
    protected bool $searchable = true;
    protected array $msg = ['created' => 'Registro criado com sucesso.', 'updated' => 'Registro atualizado com sucesso.', 'deleted' => 'Registro excluído com sucesso.'];

    abstract protected function fields(int $uid): array;
    abstract protected function columns(): array;

    protected function extra(array $item, int $uid): array { return []; }

    public function index(): void
    {
        $uid = Auth::id();
        $m = $this->model;
        $q = trim((string)($_GET['q'] ?? ''));
        $this->render($this->indexView, [
            'title' => $this->plural, 'base' => $this->base, 'singular' => $this->singular,
            'icon' => $this->icon, 'columns' => $this->columns(), 'items' => $m::listAll($uid, $q),
            'q' => $q, 'searchable' => $this->searchable,
        ]);
    }

    public function create(): void
    {
        $uid = Auth::id();
        $fields = $this->fields($uid);
        $values = [];
        foreach ($fields as $f) { // permite pré-seleção via ?campo=valor (ex.: ?project_id=3)
            if ($f['type'] === 'select' && isset($_GET[$f['name']]) && is_string($_GET[$f['name']])) {
                $values[$f['name']] = $_GET[$f['name']];
            }
        }
        $this->form(null, $values, [], $fields);
    }

    public function store(): void
    {
        $this->verifyCsrf();
        $uid = Auth::id();
        $fields = $this->fields($uid);
        [$values, $errors] = Validator::run($fields, $_POST);
        if ($errors) { $this->form(null, $values, $errors, $fields); return; }
        $m = $this->model;
        $m::create($uid, $values);
        flash('success', $this->msg['created']);
        $this->redirect('/' . $this->base);
    }

    public function show(int $id): void
    {
        $uid = Auth::id();
        $m = $this->model;
        $item = $m::findDetailed($id, $uid) ?? $this->notFound();
        $fields = $this->fields($uid);
        $rows = [];
        foreach ($fields as $f) {
            $v = $item[$f['name']] ?? null;
            $t = $f['type'];
            if ($v === null || $v === '') $d = '—';
            elseif ($t === 'select') $d = $f['options'][$v] ?? $v;
            elseif ($t === 'date') $d = fmt_date($v);
            elseif ($t === 'time') $d = substr($v, 0, 5);
            else $d = $v;
            $rows[] = ['label' => $f['label'], 'value' => $d, 'multiline' => $t === 'textarea'];
        }
        $rows[] = ['label' => 'Criado em', 'value' => fmt_datetime($item['created_at']), 'multiline' => false];
        $this->render('crud/show', [
            'title' => $item['title'], 'base' => $this->base, 'singular' => $this->singular,
            'item' => $item, 'rows' => $rows, 'extraView' => $this->extraView,
        ] + $this->extra($item, $uid));
    }

    public function edit(int $id): void
    {
        $uid = Auth::id();
        $m = $this->model;
        $item = $m::findDetailed($id, $uid) ?? $this->notFound();
        $this->form($item, $item, [], $this->fields($uid));
    }

    public function update(int $id): void
    {
        $this->verifyCsrf();
        $uid = Auth::id();
        $m = $this->model;
        $item = $m::find($id, $uid) ?? $this->notFound();
        $fields = $this->fields($uid);
        [$values, $errors] = Validator::run($fields, $_POST);
        if ($errors) { $this->form($item, $values, $errors, $fields); return; }
        $m::update($id, $uid, $values);
        flash('success', $this->msg['updated']);
        $this->redirect('/' . $this->base . '/' . $id);
    }

    public function destroy(int $id): void
    {
        $this->verifyCsrf();
        $uid = Auth::id();
        $m = $this->model;
        $m::find($id, $uid) ?? $this->notFound();
        $m::delete($id, $uid);
        flash('success', $this->msg['deleted']);
        $this->redirect('/' . $this->base);
    }

    protected function form(?array $item, array $values, array $errors, array $fields): void
    {
        $this->render('crud/form', [
            'title' => ($item ? 'Editar ' : 'Nova ') . $this->singular,
            'base' => $this->base, 'singular' => $this->singular, 'item' => $item,
            'values' => $values, 'errors' => $errors, 'fields' => $fields,
            'action' => $item ? url("/{$this->base}/{$item['id']}/update") : url("/{$this->base}"),
        ]);
    }
}
