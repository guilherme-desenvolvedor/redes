<?php
/** @var Router $router */
$router->add('GET', '/', 'HomeController@index');
$router->add('GET', '/login', 'AuthController@loginForm');
$router->add('POST', '/login', 'AuthController@login');
$router->add('GET', '/register', 'AuthController@registerForm');
$router->add('POST', '/register', 'AuthController@register');
$router->add('POST', '/logout', 'AuthController@logout');

$router->add('GET', '/dashboard', 'DashboardController@index');

$router->add('GET', '/profile', 'ProfileController@edit');
$router->add('POST', '/profile', 'ProfileController@update');
$router->add('POST', '/profile/password', 'ProfileController@password');

// CRUD completo para cada módulo
foreach (['ideas' => 'IdeaController', 'projects' => 'ProjectController',
          'scripts' => 'ScriptController', 'publications' => 'PublicationController'] as $path => $ctrl) {
    $router->add('GET',  "/$path", "$ctrl@index");
    $router->add('GET',  "/$path/create", "$ctrl@create");
    $router->add('POST', "/$path", "$ctrl@store");
    $router->add('GET',  "/$path/{id}", "$ctrl@show");
    $router->add('GET',  "/$path/{id}/edit", "$ctrl@edit");
    $router->add('POST', "/$path/{id}/update", "$ctrl@update");
    $router->add('POST', "/$path/{id}/delete", "$ctrl@destroy");
}
