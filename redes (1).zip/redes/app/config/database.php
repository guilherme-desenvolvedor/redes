<?php
/**
 * Configuração da conexão MySQL (único lugar a editar).
 * Padrão do XAMPP: host localhost, banco redes, usuário root, senha vazia.
 *
 * Também é possível sobrescrever sem editar o arquivo, definindo variáveis de ambiente:
 * REDES_DB_HOST, REDES_DB_PORT, REDES_DB_NAME, REDES_DB_USER, REDES_DB_PASS.
 */
return [
    'host'    => getenv('REDES_DB_HOST') ?: 'localhost',
    'port'    => (int)(getenv('REDES_DB_PORT') ?: 3306),
    'name'    => getenv('REDES_DB_NAME') ?: 'redes',
    'user'    => getenv('REDES_DB_USER') ?: 'root',
    'pass'    => getenv('REDES_DB_PASS') !== false ? getenv('REDES_DB_PASS') : '',
    'charset' => 'utf8mb4',
];
