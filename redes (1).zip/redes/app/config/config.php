<?php
// Configurações da aplicação REDES
return [
    'app_name' => 'REDES',
    'timezone' => 'America/Sao_Paulo',
    'debug'    => false, // true apenas em desenvolvimento
    'db' => require __DIR__ . '/database.php', // veja database.php
];
