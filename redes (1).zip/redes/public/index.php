<?php
declare(strict_types=1);

define('ROOT', dirname(__DIR__));
define('APP_PATH', ROOT . '/app');
define('VIEW_PATH', APP_PATH . '/views');

require APP_PATH . '/core/helpers.php';

spl_autoload_register(function (string $class): void {
    foreach (['core', 'models', 'controllers'] as $dir) {
        $file = APP_PATH . "/$dir/$class.php";
        if (is_file($file)) { require $file; return; }
    }
});

date_default_timezone_set(config('timezone'));

set_exception_handler(function (Throwable $e): void {
    error_log('[REDES] ' . $e->getMessage() . ' em ' . $e->getFile() . ':' . $e->getLine());
    http_response_code(500);
    $detail = config('debug') ? $e->getMessage() . ($e->getPrevious() ? ' | ' . $e->getPrevious()->getMessage() : '') : null;
    $view = ($e instanceof DatabaseException && $e->isConnection()) ? 'errors/db' : 'errors/500';
    render_view($view, ['detail' => $detail], 'auth');
});

header('X-Frame-Options: SAMEORIGIN');
header('X-Content-Type-Options: nosniff');
header('Referrer-Policy: same-origin');

Auth::start();

$router = new Router();
require APP_PATH . '/config/routes.php';
$router->dispatch();
